# The inspection gallery

## Creative direction

One quiet architectural room, two vehicles, one dealership. The arrival establishes weight and scale. A stationary car is then studied with a moving camera: body, tyre, mechanical inspection, the open cabin doorway and records. The first vehicle drives away before the next arrives. Both vehicles return through continuous routes outside the studio and park side by side. The visitor takes control of the view, ignition and sound before moving on to the collection.

The supplied `studio_v1_for_car.glb` provides the architecture, ceiling strips and slate floor. Its rear wall was opened for vehicle access. The gallery is 40 m wide and 80 m long, with a 7.9 m ceiling. All vehicle footprints and both camera paths are checked against those clearances. The original source is retained.

## Lighting research and application

- [Three.js PMREMGenerator](https://threejs.org/docs/pages/PMREMGenerator.html): roughness-dependent environment filtering. The actual studio is captured once at the inspection position, without cars. Its strip fixtures create coherent highlights on clearcoat and chrome. The 1K HDR is used as subdued bounce during that capture. The environment is a static approximation, most accurate at the inspection position.
- [Three.js RectAreaLight](https://threejs.org/docs/pages/RectAreaLight.html): broad rectangular sources produce soft automotive highlights. Five exterior sources provide a following key, side separation, front fill and continuous light along the driving route. Area lights do not cast shadows in Three.js; the vehicles use baked contact shadows, and a subtle desktop reflection supplies additional grounding.
- [Official Three.js car example](https://threejs.org/examples/webgl_materials_car.html): layered physical paint, clearcoat, environment lighting and a separate contact-shadow treatment. This project uses the same material principles with the supplied vehicles and inspected material names.
- [Three.js colour management](https://threejs.org/manual/pages/color-management.html): linear lighting calculations, correct texture roles and display conversion. GLTFLoader handles the original material texture colour spaces. ACES tone mapping controls highlights. The GLS/Maybach cabin base colours and original ambient-strip hue are preserved. The dashboard, leather and wood have corrected metalness/roughness to respond naturally to the cabin lights.

The floor keeps the source colour and normal textures. Its packed metal/roughness response is replaced with matte, nonmetallic slate to avoid a wet, mirror-like floor. A shader approximates soft indirect illumination around the studio's existing strip fixtures. There is no bloom pass.

### Cabin and dashboard displays

Two local area lights represent windscreen and headliner fill. Two short-range accent sources provide subtle light around the console and footwell, using the model's authored purple hue. These lights travel with the vehicle and brighten for the open-door view and respond to ignition in the final lineup. The original interior colour values are unchanged.

The audited `gls_gauges_screen` and `gls_gps_screen` surfaces receive instrument and navigation artwork through [Three.js CanvasTexture](https://threejs.org/manual/pages/canvas-textures.html) and [emissive material maps](https://threejs.org/docs/pages/MeshStandardMaterial.html). The preparation had stripped their UVs; a vehicle-space projection restores them. Clear glazing is assigned only to the triangles over the displays and front headlamps, preserving the window tint elsewhere. The displays are illustrative, with a stationary speed indication and an abstract map; they do not invent stock mileage or verified history.

## Motion research and application

- [Marco Monster, Car Physics for Games](https://rmgi.blog/marco-monster-car-physics/) (archived original article, 2003): separation of longitudinal travel, steering and weight transfer. Here those visual cues are represented by distance-driven wheels, curvature-driven front steering and restrained chassis pitch. This is deterministic choreography, not a driving simulator.
- [Three.js Curve](https://threejs.org/docs/pages/Curve.html): arc-length sampling keeps wheel rotation tied to metres travelled. The car heading follows the path tangent. A quintic distance curve gives continuous acceleration and braking; reverse scrolling reconstructs the same pose.
- [Bruno Simon, Crafting Scroll Based Animations in Three.js](https://tympanus.net/codrops/2022/01/05/crafting-scroll-based-animations-in-three-js/): coordinating the DOM and a 3D camera with scroll, including responsive framing. This site uses dedicated portrait camera positions and a final wide composition for the two-car lineup.
- [GSAP ScrollTrigger](https://gsap.com/docs/v3/Plugins/ScrollTrigger/): one scrubbed playhead controls all vehicle, camera, lighting and copy state. The camera remains outside the body after the open-door view, completes full exterior orbits and follows each forward departure. There are no camera cuts or transition wipes. Both return routes preserve position, heading and wheel-distance continuity; a final stationary interval leaves room for interaction.

### Interactive lights and sound

- [Three.js SpotLight](https://threejs.org/docs/pages/SpotLight.html): two lamps per vehicle use inverse-square falloff, soft cone edges and a finite range to illuminate the actual floor. Emissive running-light and projector materials, direction-dependent flare sprites and restrained rear-floor glow respond to the ignition controls. These are raster lighting approximations, without volumetric scattering or additional shadow maps.
- [MDN Web Audio best practices](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API/Best_practices): sound begins only from an explicit engine-button interaction. Original procedural starter and idle buffers distinguish eight-cylinder and six-cylinder rhythms. Independent gain stages allow both engines to run; mute and offscreen/hidden-tab fading control the master output. These sounds are authored approximations, not vehicle recordings.
- [Three.js OrbitControls](https://threejs.org/docs/pages/OrbitControls.html): the interaction follows the familiar drag-to-orbit convention. A small custom spherical controller keeps the camera radius within the studio, limits elevation above the floor/below the ceiling, and supports pointer capture, touch, buttons and keyboard input. Cars stay stationary during camera rotation.

## Asset and rendering budget

- Studio: 11,791,300 → 247,420 bytes; 176 triangles; 1024 px WebP floor textures.
- Meshopt compressed vehicle models; 1K HDR bounce on all devices.
- One studio environment capture during loading; no per-frame environment captures.
- Low-resolution desktop floor reflection; no reflection render pass on mobile.
- Adaptive pixel ratio; rendering stops when unchanged or hidden. No continuous idle rendering is required for engine sound.
- Local variable fonts: DM Sans and Manrope, with OFL licences included.
- Reduced motion skips model downloads. Loading/WebGL failure leaves the practical site usable.

## Verification

`npm test` checks wheel travel, heading, steering limits, reversibility, camera/body clearance, uninterrupted full 360° orbits, final parking, and studio wall/ceiling clearance. `npm run check:browser` checks desktop and portrait scrolling, the open-door view, independent ignition/audio/lights, mouse and touch orbiting, keyboard controls, offscreen silence, inventory boundary, navigation, forms, reduced motion and WebGL failure. Browser frame captures are also reviewed visually; numerical clearance alone cannot verify composition.
