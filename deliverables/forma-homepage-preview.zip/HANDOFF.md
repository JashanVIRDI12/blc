# FORMA Motor House — homepage handoff

## Included

The finished homepage design includes the supplied studio, a scroll-controlled vehicle film, responsive collection, vehicle details, valuation and enquiry forms, dealership information and privacy dialog. Original GLS/Maybach interior colours are retained. The open-door view is the last close-up. It flows into a full exterior 360° move and forward departure, without a cabin cut or transition wipe.

The lighting revision adds illumination along the driving route, soft architectural light, local cabin fill and the original purple ambient-strip hue. The two dashboard displays now show illustrative instruments and navigation, fitted to the actual screen surfaces. Their content is decorative and does not represent a stock record or live navigation service.

Both vehicles then return to a side-by-side interactive lineup. Mouse or touch dragging rotates the camera; arrow buttons and keyboard controls provide alternatives. Individual start/stop controls enable headlights, floor beams, tail lamps and engine sound. A mute control preserves the lights, and audio fades to silence offscreen or in a hidden tab. The sounds are original procedural V8- and six-cylinder-inspired audio, not factory recordings.

The build is suitable for client preview. The current identity is **FORMA Motor House**, and the two vehicles are explicitly labelled collection previews.

## Information required for public launch

Update `src/config.js` with the approved dealership identity, contact details and actual inventory. No dealership contact, live stock records or enquiry endpoint were supplied during implementation.

- `dealer.name` and `dealer.descriptor`: approved brand.
- `dealer.phone`, `dealer.whatsapp`, `dealer.email`, `dealer.address`: published contact details.
- `dealer.enquiryEndpoint`: optional endpoint accepting JSON enquiry/valuation requests. See `src/forms.js` for the payload.
- `inventory`: actual records following `docs/INVENTORY.md`.

Until delivery is configured, forms prepare a copyable/downloadable draft and explicitly state that nothing was sent. Email/WhatsApp configuration adds a visitor-initiated sharing action. A connected endpoint enables online submission. Prices, kilometres, ownership counts and inspection results must come from real records.

## Run or build

```sh
npm install
npm run dev -- --host 127.0.0.1 --port 5174
npm test
npm run build
npm run preview -- --host 127.0.0.1 --port 4174
```

Upload the **contents of `dist/`** to the root of a static HTTPS host. Serve through HTTP/HTTPS; opening `index.html` directly from a file manager will not load the modules and models correctly. The current asset URLs assume the site is hosted at the domain root.

The optional preview ZIP contains the production site and this handoff document. It does not contain an enquiry backend. The workspace retains the editable source, original supplied models and reproducible preparation scripts.

## Verified in this delivery

- Eleven mathematical motion/clearance tests, including continuous full orbits and the final lineup.
- Desktop scrolling, reverse scrolling and the film-to-inventory boundary.
- Portrait framing, open-door display visibility, navigation and horizontal overflow.
- Mouse/touch drag, independent engine controls, actual audio output, mute, lamp/beam state, keyboard reset and offscreen silence.
- Collection search/filtering, detail dialogs and enquiry/valuation drafts.
- Reduced motion without GLB downloads.
- WebGL failure with usable static collection.
- Production bundle build and a local production browser review.

Screenshots were reviewed in headless Chrome at 1440×960 and 390×844. Physical iOS/Safari testing was not performed. The Three.js film is a separate lazy-loaded bundle; Vite reports the expected large-chunk warning for that bundle.

## Assets and research

The supplied studio was reduced from 11.8 MB to 247 KB. Its rear wall was opened for car access, and the camera space was scaled to keep both desktop and portrait paths inside the room. The original source file is unchanged.

See `docs/LIGHTING-AND-MOTION.md` for lighting/camera sources and `docs/studio-audit.json` for studio preparation details. Font licences are included under `public/fonts/` and in the production output.
