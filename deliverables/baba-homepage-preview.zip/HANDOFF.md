# Baba Luxury Cars — homepage handoff

## Included

The homepage now uses the requested Baba Luxury Cars identity. A short studio film leads into a white brand introduction with copy on the left and two cars on the right, followed by Featured Collection, The Baba Standard, Sell or Exchange, and the footer.

The Maybach uses a Kalahari Gold / Obsidian Black two-tone exterior inspired by the manufacturer's reference. Its grille slats are silver and the front, rear-side and tailgate glass have a lighter privacy tint. Original interior colours and illuminated dashboard screens are retained. After the interior reveal, the door closes fully and the car drives forward out of the scene, tracked by the camera. The former 360° sequences, return loops, ignition controls and sound system have been removed.

The 3D white gallery reuses the supplied Maybach and X7 geometry, with controlled neutral lighting and contact shadows. Mobile uses a stacked composition; sharp, approximately 1800-pixel static fallbacks use the same updated vehicle finishes. Settled desktop film frames render at up to 2× device pixel density.

## Client data

No verified stock records, dealership contact details or enquiry endpoint were supplied. The collection therefore contains labelled showcase previews, with no invented prices, mileage or ownership history. Update `src/config.js` with approved contact information and actual inventory before public launch.

Forms currently prepare a copyable/downloadable enquiry and explicitly state that nothing has been sent. An email/WhatsApp contact enables visitor-initiated sharing; an optional POST endpoint enables online delivery. See `docs/INVENTORY.md` and `src/forms.js`.

## Run and deliver

```sh
npm install
npm run dev -- --host 127.0.0.1 --port 5174
npm test
npm run build
npm run preview -- --host 127.0.0.1 --port 4174
```

Upload the contents of `dist/` to the root of a static HTTPS host. Serve through HTTP/HTTPS, not by opening `index.html` as a local file. The preview ZIP contains the production files and handoff documents; it does not contain an enquiry backend.

## Verification

- Eleven tests cover distance-driven wheels, heading and steering, reversibility, camera and vehicle clearance, continuous camera travel, and closure of the door before departure.
- Local Chrome review covers desktop and portrait composition, the white gallery, section order, absence of engine controls, collection filters, dialogs, enquiry/valuation drafts, reduced motion and WebGL failure.
- Production build and a browser review of the compiled assets. A separate Retina browser check verifies the full-resolution settled frame.

Screenshots are reviewed at 1440×960 and 390×844. Physical iOS/Safari testing was not performed. Vite reports the expected large-chunk warning for the separately loaded Three.js film.

Read `docs/REDESIGN-NOTES.md` for the visual direction, paint reference, design articles and technical choices. `docs/IMPROVED-PROMPT.md` is a concise, reusable version of the creative brief. The supplied source models remain unchanged. Font licences are included in the production files.
