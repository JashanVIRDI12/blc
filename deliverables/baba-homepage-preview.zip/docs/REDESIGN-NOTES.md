# Baba Luxury Cars — design direction

## Homepage structure

1. A shorter studio film: exterior details, bonnet, interior through the open door, door closure, forward departure. The BMW receives a brief exterior study and drives away. There are no full orbits, return loops, engine controls or engine audio.
2. A white introduction to Baba Luxury Cars: the brand story at left and the two actual 3D vehicles at right. The Maybach leads in Kalahari Gold and Obsidian Black. Mobile places the vehicles below the introduction.
3. Featured collection, with clear preview labels, search, make filtering and vehicle enquiries.
4. The Baba standard: three concise disclosures about condition, documentation and the next step.
5. Sell or exchange, retaining the functional valuation enquiry.
6. A compact footer with contact action, navigation and privacy information.

## Research applied

- [Mercedes-Benz: the new Mercedes-Maybach GLS](https://media.mbusa.com/news/the-new-mercedes-maybach-gls). The manufacturer describes Obsidian Black on the lower body with Kalahari Gold above, and a fine dividing pinstripe. The prepared model now uses that two-tone arrangement, applied only to its paint meshes. The shader boundary is recorded in each panel's rest pose so the finish stays attached when the door or bonnet opens. The displayed gold is an art-directed digital approximation, not a certified paint sample. The cabin palette is unchanged.
- [Locomotive / Awwwards: typography in motion](https://assets.awwwards.com/assets/files/live-presentation.pdf). A coherent type direction can establish the composition. Here the existing local Manrope and DM Sans fonts carry the interface, while restrained italic serif accents mark a few editorial phrases. This is an original layout; no paid font or artwork from the reference is used.
- [Nielsen Norman Group: Scroll Fading 101](https://www.nngroup.com/articles/scroll-fading-101/). Apply fades sparingly, keep content available and avoid competing moving elements. Below the film, short once-only copy reveals accompany a stationary product composition. The collection remains in normal page flow and the main navigation gives direct access to it.
- [Nielsen Norman Group: The Role of Animation and Motion in UX](https://www.nngroup.com/articles/animation-purpose-ux/). Motion should communicate an understandable change. The door closes completely before the departure starts, and the next section presents a clear change from cinematic inspection to dealership information.
- [Awwwards / Addy Osmani: Designing for Mobile Performance](https://www.awwwards.com/brainfood-mobile-performance-vol3.pdf). Deliver essential UI first and defer expensive work. The practical site loads separately from Three.js. The white gallery reuses the already loaded geometry and initializes its renderer near the viewport. It renders only on entry or resize. Reduced motion avoids all model downloads.

## Rendering

The original studio and its architectural lights remain in the film. The white gallery uses a separate neutral environment, broad area lights and baked contact shadows. It has no idle animation, audio or orbit controls. On narrow screens it uses a wider lens and a stacked layout. Still images of the same supplied models and updated paint provide fallbacks.

The gallery allocates a second WebGL context only near its section; CPU geometry is shared with the film, with independent material instances. Physical iOS/Safari testing remains outside this local Chrome review.

## Final image pass

The Maybach's rear side and tailgate panes were authored with an almost opaque metallic material, separate from its front glass. They now use a lighter privacy tint, and cabin softboxes reveal the original seats without recolouring them. The front grille slats and surround have their own silver material, selected from the source mesh by connected geometry so nearby black trim stays dark. Film light panels, environment bounce, headlamp spill and studio strips have been lowered to preserve paint definition. The departure camera follows the vehicle instead of leaving an empty room in frame. The active scene restores up to 2× device resolution after a scroll settles, and newly rendered fallback stills are about 1800 pixels wide.
