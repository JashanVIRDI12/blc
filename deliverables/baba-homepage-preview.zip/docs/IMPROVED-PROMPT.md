# Baba Luxury Cars — refined creative and implementation brief

Create a client-ready homepage for **Baba Luxury Cars**, a premium pre-owned vehicle dealership. Baba is the brand. The Mercedes-Maybach GLS 600 and BMW X7 are examples of its collection, not separate manufacturer campaigns. Build on the existing site, supplied vehicle models, and supplied studio. Keep the result restrained, credible, responsive, and practical to use.

## Art direction

Use a dark architectural studio for one short, continuous scroll-controlled film. Follow it with a bright white editorial page for Baba's introduction, featured collection, dealership standards, one sell or exchange section, and a concise footer. Use generous space, strong type hierarchy, warm neutral accents, and precise details. Avoid excessive cards, neon, heavy bloom, dense effects, and copy that sounds like a generic luxury template.

The Maybach has a Kalahari Gold upper body and Obsidian Black lower body, with a subtle dividing line. Keep the original cabin upholstery, wood, dashboard, and ambient-light colours. Give its vertical grille slats and surround a distinct **silver chrome** finish; keep the grille recess and nearby black trim dark. Its glazing should be lightly smoked, with both front and rear seats visible from exterior views. Keep the BMW in its supplied colour.

## Film choreography

The car enters under its own power, settles, and is inspected through deliberate camera moves. Show bodywork, wheels, bonnet and engine, then the cabin through the open driver's door. Populate the real dashboard screen meshes with restrained, believable displays. Close the door fully before departure. Track the car as it drives forward away; keep it visible while the departure copy is on screen. Bring in the BMW naturally in the same studio, give it a shorter exterior study, and let it depart. The camera must move continuously: no interior cut, teleport, full 360-degree orbit, reverse-drive illusion, or overlapping vehicle poses.

Use GSAP ScrollTrigger to bind motion to scrolling and support clean reversal. Camera position, look target, vehicle travel, wheel rotation, steering, door hinges, copy fades, and lighting should agree at every point on the timeline. Give reduced-motion visitors a useful static page without requiring 3D downloads.

## Lighting and image quality

Art-direct paint with broad warm and neutral softboxes, a subtle cool rim, controlled environment reflections, and grounded contact shadows. Keep the gold metallic and the black body legible without blowing out the paint or making the floor a gray wash. Studio strips should add structure, not become the main subject. Headlights and rear lights should read as believable lamps, with restrained floor spill and no oversized glow.

Render stationary frames at the device's native pixel density up to 2× on desktop. During sustained slow scrolling, resolution may step down for responsiveness, but restore full detail shortly after scrolling stops. Use crisp, high-resolution images of the actual supplied models for static fallbacks and collection cards. Preserve detailed geometry, tyre texture, chrome edges, interior definition, and readable dashboard displays.

## Page and product requirements

After the film, present Baba's story on the left and both real 3D cars together on a **white** background at the right. On mobile, stack them beneath the copy. Continue with Featured Collection, Baba's standards, sell or exchange, and a footer. Keep navigation and collection access immediate. Do not add ignition buttons, engine sound, sound toggles, or draggable 360-degree controls.

Show only supplied vehicle facts. If service history, ownership count, mileage, price, or contact endpoint is unknown, disclose that clearly rather than inventing it. Keep enquiry and valuation flows usable without pretending an unconnected form has sent data.

## Acceptance review

Review the film at its opening, inspection, open door, closed door, departure, second car, and final handoff. Confirm the silver grille, light tint, visible rear seats, consistent original cabin palette, believable light levels, and sharp Retina render. Check desktop and mobile composition, scroll reversal, reduced motion, browser exceptions, image fallbacks, filter and enquiry controls, and final production build. Deliver the editable source, current preview, and a short note on any missing client data.
